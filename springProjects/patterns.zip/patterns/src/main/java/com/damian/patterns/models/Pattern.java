package com.damian.patterns.models;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;


@Entity
public class Pattern {


	
	@Id
	@GeneratedValue
	public Long Id;
	
	public String Intervals;
	
	public String Name;
	
	public String Code;
	
	public String Duration;
	

	
	
	public Pattern() {
	}
	
	public Long getId() {
		return Id;
	}

	public void setId(Long id) {
		id = Id;
	}
	
	public String getIntervals() {
		return Intervals;
	}

	public void setIntervals(String intervals) {
		intervals = Intervals;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		name = Name;
	}

	public String getCode() {
		return Code;
	}

	public void setCode(String code) {
		code = Code;
	}

	public String getDuration() {
		return Duration;
	}

	public void setDuration(String duration) {
		duration = Duration;
	}
	
}
