package com.damian.patterns.repositories;

import java.util.ArrayList;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;

import com.damian.patterns.models.Pattern;




public interface PatternRepository extends CrudRepository<Pattern, Long> {
	
	@Query
	(nativeQuery = true, value = "SELECT * FROM pattern GROUP BY `Name`")
	ArrayList<Pattern> fetchNames();
	
}
