package com.damian.patterns.services;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.damian.patterns.models.Pattern;
import com.damian.patterns.repositories.PatternRepository;

@Service
public class PatternService {

	
	private PatternRepository patternRepository;
	
	public PatternService(PatternRepository patternRepository) {
		this.patternRepository = patternRepository;
	}
	
	@Autowired
	public ArrayList<Pattern> all() {
		return (ArrayList<Pattern>) patternRepository.findAll();
		
	}
	
}
