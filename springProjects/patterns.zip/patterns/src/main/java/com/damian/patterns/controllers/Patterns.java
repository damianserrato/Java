package com.damian.patterns.controllers;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;
import com.damian.patterns.models.Pattern;
import com.damian.patterns.repositories.PatternRepository;




@Controller
public class Patterns {
		
		@Autowired
		private PatternRepository repo;

		
		@RequestMapping("")
		public String index() {
			return "index";
		}
		 
		@RequestMapping("searchAll")
		public ModelAndView patterns() throws ParseException {
			
			 ModelAndView mv = new ModelAndView("showinfo");
			
			 ArrayList<Pattern> allAgents =   (ArrayList<Pattern>) repo.findAll();
			 ArrayList<Pattern> compatibleAgents =   new ArrayList<Pattern>();
			 
			 SimpleDateFormat date = new SimpleDateFormat("HH:mm:ss");
			 
				 for(Pattern i: allAgents) {
					 
						for(Pattern e: allAgents) {
							String str1 = i.Duration;
							String str2 = e.Duration;
							
							if(!str1.equals("") && !str2.equals("")) {
								Date time1 = date.parse(str1);
								Date time2 = date.parse(str2);
								
								long timeDiff = time1.getTime() - time2.getTime();
								
								long diffResult = timeDiff/60000;
								
								if(i.Code.equals(e.Code) && i.Intervals.equals(e.Intervals) && (diffResult == 0)) {
									
									compatibleAgents.add(e);
									
								}
							}
						}
					}
				 
			mv.addObject("compatibleAgents", compatibleAgents);
			
			
			return mv;
		}
		
		@RequestMapping("searchName")
		public ModelAndView byName() {
			ModelAndView mv1 = new ModelAndView("searchName");
			
			ArrayList<Pattern> perfect =  (ArrayList<Pattern>) repo.fetchNames();
			
			
			mv1.addObject("perfect", perfect);
			
			return mv1;
		}
		
		@RequestMapping(value = "byagent", method = RequestMethod.POST)
		public ModelAndView byAgent(@RequestParam("thisname") String thisName) throws ParseException {
			ModelAndView mv2 = new ModelAndView("byagent");
			
			ArrayList<Pattern> particular = (ArrayList<Pattern>) repo.findAll();
			ArrayList<Pattern> singleAgent = new ArrayList<Pattern>();
			ArrayList<Pattern> compatibleAgents = new ArrayList<Pattern>();
			ArrayList<Pattern> test1 = new ArrayList<Pattern>();
			
			for(Pattern i: particular) {
				if(i.Name.equals(thisName)) {
					singleAgent.add(i);
				}
			}
			
			SimpleDateFormat date = new SimpleDateFormat("HH:mm:ss");
					
			for(Pattern i: particular) {
				
				for(Pattern e: singleAgent) {
					String str1 = i.Duration;
					String str2 = e.Duration;
					
					if(!str1.equals("") && !str2.equals("")) {
						Date time1 = date.parse(str1);
						Date time2 = date.parse(str2);
						
						long timeDiff = time1.getTime() - time2.getTime();
						
						long diffResult = timeDiff/60000;
					
						if(i.Code.equals(e.Code) && i.Intervals.equals(e.Intervals) && (diffResult == 0) && !i.Name.equals(e.Name)) {
							compatibleAgents.add(i);
						}
					}
				}
			}
			
			mv2.addObject("singleAgent", singleAgent);
			mv2.addObject("compatibleAgents", compatibleAgents);
			mv2.addObject("test1", test1);
			
			return mv2;
		}
}
