public class PythagoreanTheoremTest {
    public static void main(String[] args) {
        PythagoreanTheorem iD = new PythagoreanTheorem();
        Double hypotenuse = iD.calculateHypotenuse();
        System.out.println(hypotenuse);
}
}